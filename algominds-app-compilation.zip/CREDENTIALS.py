userid = "TEST05"     
password = "Test05@"      
pin = '1111'
secret_key = "LHaJpfvuJjDoSjW7q8ejMJr3ZUjTtKMv"
api = "http://15.235.153.112/api"
tradingAPI = "https://tlapi.munirkhanani.com/api"
wsAPI = "wss://tlapi.munirkhanani.com:24002"
socket_token = 'ZXlKMGVYQWlPaUpLVjFRaUxDSmhiR2NpT2lKSVV6STFOaUo5LmV5SnBZWFFpT2pFM05UVXdPREkwTmpVc0ltVjRjQ0k2TVRjMU5UQTRPVFkyTlN3aWRYTmxjbTVoYldVaU9pSlVSVk5VTURVaUxDSnBjME52Ym01bFkzUWlPaUpaSWl3aWRXNXhJam9pVFdwVk5FOVVWVDBpZlEuU1F6dGFHcTg4YllXTlp4R0pFZ2Vjb3F5ZHpvXzBhcmlHZGZrRkY3SDdmVQ=='
Authorization = 'Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpYXQiOjE3NTUwODI0NjUsImV4cCI6MTc1NTA4MzA2NSwiY2xpZW50X2lkIjoiVEVTVDA1Iiwic2VxX25vIjoiMjI5IiwibG9naW5fdW5pcXVlX2lkIjoiMjU4OTUiLCJsb2dpbl91bmlxdWVfaWRfZW5jIjoiMEpaQiIsImlzQ29ubmVjdCI6MH0.5mcHPZlmrbeprKrnhRh25ajfxnZe1GhthkahTnhlvDM'
X_Refresh_Token = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpYXQiOjE3NTUwODI0NjUsImV4cCI6MTc1NTA4MzM2NSwiY2xpZW50X2lkIjoiVEVTVDA1Iiwic2VxX25vIjoiMjI5IiwibG9naW5fdW5pcXVlX2lkIjoiMjU4OTUiLCJsb2dpbl91bmlxdWVfaWRfZW5jIjoiMEpaQiIsImlzQ29ubmVjdCI6MH0.W5amR1igkypGZb7DY3IDfztrF9G3MEfv0GbxWmu90J0'
client_code = 222
app_secret_key = '0642fa7bdc069bf88a4d634c89ddfc95'

pendingOrderValue = 0.0
portfolioMarketValue = 1395.8
totalWorth = 10897.55
balance = 9501.75
cashWithdrawalLimit = 4501.75

useridtl = '222C'
passwordtl = 'S@101tl'
pintl = 1811

dbname = 'AlgoMinds'
dbpassword = 'machinedatabase'
dbuser = 'algominds'
