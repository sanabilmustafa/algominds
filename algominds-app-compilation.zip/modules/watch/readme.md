missing fields in tick data:
close-price
change value
upper cap
lower cap
last trade time comes but with null value


symbol
bid vol
bid price
ask price
ask volume
change value
total volume
high 
low
last trade price
change %
upper cap
lower lock
close price
open price
last trade volume
total trade
last trade time
average
symbol state