# from flask import render_template
# from . import screener_bp, db
# import json
# from flask import Blueprint, render_template, jsonify, request
# from flask_sock import Sock
# from flask_cors import CORS
# from sqlalchemy.dialects.postgresql import JSONB
# from sqlalchemy.orm import relationship
# from datetime import datetime
# from api_calls import get_client_auth, get_market_status
# import CREDENTIALS
# # from modules.database import db
# # from modules.screener.models import ScreenerProfile, ScreenerProfileItem, Stock
# class Screener(db.Model):
#     __tablename__ = 'screener'

#     screener_id = db.Column(db.Integer, primary_key=True)
#     client_id = db.Column(db.Integer, nullable=False)

#     def __repr__(self):
#         return f"<Screener {self.screener_id}>"


# class ScreenerProfile(db.Model):
#     __tablename__ = 'screener_profile'

#     profile_id = db.Column(db.Integer, primary_key=True)
#     screener_id = db.Column(db.Integer, db.ForeignKey('screener.screener_id'), nullable=False)
#     profile_name = db.Column(db.String, nullable=False)
#     filters = db.Column(JSONB, nullable=True)
#     created_at = db.Column(db.DateTime, default=datetime.utcnow)

#     is_default = db.Column(db.Boolean, default=False)
#     def __repr__(self):
#         return f"<ScreenerProfile {self.profile_name}>"

# from sqlalchemy.dialects.postgresql import JSONB

# class ScreenerProfileItem(db.Model):
#     __tablename__ = 'screener_profile_items'

#     item_id = db.Column(db.Integer, primary_key=True)
#     profile_id = db.Column(db.Integer, db.ForeignKey('screener_profile.profile_id'), nullable=False)
#     stock_id = db.Column(db.Integer, db.ForeignKey('stock.stock_id'), nullable=False)
#     added_at = db.Column(db.DateTime, default=datetime.utcnow)
#     selected_columns = db.Column(JSONB)


#     __table_args__ = (
#         db.UniqueConstraint('profile_id', 'stock_id', name='unique_profile_stock'),
#     )

#     def __repr__(self):
#         return f"<ScreenerProfileItem Profile: {self.profile_id}, Stock: {self.stock_id}>"


# class MarketData(db.Model):
#     __tablename__ = 'market_data'
#     # __table_args__ = {'autoload_with': db.engine}

#     market_data_id = db.Column(db.Integer, primary_key=True)
#     record_identifier = db.Column(db.String(10))
#     symbol_code = db.Column(db.String(10))
#     market_code = db.Column(db.String(10))
#     symbol_state = db.Column(db.String(10))
#     symbol_flag = db.Column(db.String(10))
#     bid_volume = db.Column(db.Numeric)
#     bid_price = db.Column(db.Numeric)
#     ask_price = db.Column(db.Numeric)
#     ask_volume = db.Column(db.Numeric)
#     last_trade_price = db.Column(db.Numeric)
#     last_trade_volume = db.Column(db.Numeric)
#     last_trade_time = db.Column(db.String(10))
#     last_day_close_price = db.Column(db.Numeric)
#     symbol_direction = db.Column(db.String(10))
#     average_price = db.Column(db.Numeric)
#     high_price = db.Column(db.Numeric)
#     low_price = db.Column(db.Numeric)
#     net_change = db.Column(db.Numeric)
#     total_traded_volume = db.Column(db.Numeric)
#     total_trades = db.Column(db.Numeric)
#     open_price = db.Column(db.Numeric)
#     timestamp = db.Column(db.DateTime)
    
# class Stock(db.Model):
#     __tablename__ = 'stock'

#     stock_id = db.Column(db.Integer, primary_key=True)
#     symbol = db.Column(db.String(20), nullable=False)
#     company = db.Column(db.String(255), nullable=False)
#     sector = db.Column(db.String(255), nullable=True)

#     def __repr__(self):
#         return f"<Stock {self.symbol}>"
    
    
# sock = Sock()
# clients = []

# CORS(screener_bp)


# # ========= HTML VIEW ===========
# @screener_bp.route('/')
# def index():
#     return render_template('/screener.html')


# # ========= WEBSOCKET ===========
# @sock.route('/screener/ws')
# def feed_socket(ws):
#     clients.append(ws)
#     print("🟢 Screener client connected.")
#     try:
#         while True:
#             data = ws.receive()
#             if data is None:
#                 break
#     except Exception as e:
#         print(f"WebSocket error: {e}")
#     finally:
#         clients.remove(ws)
#         print("🔴 Screener client disconnected.")


# # ========= API ROUTES ==========

# @screener_bp.route('/api/stocks/symbols')
# def get_symbols():
#     try:
#         symbols = db.session.query(Stock.symbol).distinct().order_by(Stock.symbol).all()
#         return jsonify([row[0] for row in symbols])
#     except Exception as e:
#         return jsonify({'error': str(e)}), 500


# @screener_bp.route('/api/stocks/sectors')
# def get_sectors():
#     try:
#         sectors = db.session.query(Stock.sector).distinct().all()
#         return jsonify([row[0] for row in sectors])
#     except Exception as e:
#         return jsonify({'error': str(e)}), 500

# @screener_bp.route('/api/market_status')
# def market_status():
#     try:
#         headers = get_client_auth(CREDENTIALS.userid, CREDENTIALS.password)[0]
#         status_data = get_market_status(headers)
#         print("⚠️ /api/market_status was called")
#         return jsonify(status_data)
#     except Exception as e:
#         return jsonify({'error': str(e)}), 500
    
    
# @screener_bp.route('/api/last_market_data')
# def get_last_market_data():
#     print("✅ CHECK: Route hit")
#     try:
#         print("⏳ Querying the DB...")
#         # Query the most recent data for each symbol
#         subquery = db.session.query(
#             MarketData.symbol_code,
#             db.func.max(MarketData.timestamp).label('max_timestamp')
#         ).group_by(MarketData.symbol_code).subquery()

#         data = db.session.query(MarketData).join(
#             subquery,
#             db.and_(
#                 MarketData.symbol_code == subquery.c.symbol_code,
#                 MarketData.timestamp == subquery.c.max_timestamp
#             )
#         ).all()

#         result = []
#         for row in data:
#             result.append({
#                 "symbol_code": row.symbol_code,
#                 "market_code": row.market_code,
#                 "last_trade_price": float(row.last_trade_price or 0),
#                 "bid_price": float(row.bid_price or 0),
#                 "ask_price": float(row.ask_price or 0),
#                 "net_change": float(row.net_change or 0),
#                 "total_traded_volume": float(row.total_traded_volume or 0),
#                 "high_price": float(row.high_price or 0),
#                 "low_price": float(row.low_price or 0),
#                 "open_price": float(row.open_price or 0),
#                 "last_day_close_price": float(row.last_day_close_price or 0),
#                 "timestamp": row.timestamp.isoformat() if row.timestamp else None
#             })

#         print(f"✅ Returning {len(result)} records")
#         return jsonify(result)

#     except Exception as e:
#         print("❌ Error fetching last market data:", e)
#         return jsonify({'error': str(e)}), 500
 
 
# @screener_bp.route('/api/get_profiles')
# def get_profiles():
#     try:
#         profiles = db.session.query(ScreenerProfile).filter_by(screener_id=1).all()
#         return jsonify([
#     {
#         'id': p.profile_id,
#         'name': p.profile_name,
#         'is_default': p.is_default  # Include this
#     } for p in profiles
# ])

#     except Exception as e:
#         return jsonify({'error': str(e)}), 500


# @screener_bp.route('/api/get_profile_stocks/<int:profile_id>')
# def get_profile_stocks(profile_id):
#     try:
#         stocks = db.session.query(Stock.symbol).join(ScreenerProfileItem, Stock.stock_id == ScreenerProfileItem.stock_id) \
#             .filter(ScreenerProfileItem.profile_id == profile_id).all()
#         return jsonify([row[0] for row in stocks])
#     except Exception as e:
#         return jsonify({'error': str(e)}), 500


# @screener_bp.route('/api/create_profile', methods=['POST'])
# def create_profile():
#     data = request.get_json()
#     profile_name = data.get('profile_name')
#     symbols = data.get('stocks', [])
#     is_default = data.get('is_default', False)
#     screener_id = 1  # TODO: make dynamic later
#     selected_columns = data.get("selected_columns", [])

#     if not profile_name or not symbols:
#         return jsonify({'error': 'Profile name and stocks are required'}), 400

#     try:
#         if is_default:
#             db.session.query(ScreenerProfile).filter_by(
#                 screener_id=screener_id, is_default=True
#             ).update({'is_default': False})

#         # ✅ Remove selected_columns here
#         new_profile = ScreenerProfile(
#             profile_name=profile_name,
#             screener_id=screener_id,
#             is_default=is_default
#         )
#         db.session.add(new_profile)
#         db.session.flush()  # to get new_profile.profile_id

#         stock_ids = dict(db.session.query(Stock.symbol, Stock.stock_id)
#                          .filter(Stock.symbol.in_(symbols)).all())

#         for symbol in symbols:
#             stock_id = stock_ids.get(symbol)
#             if stock_id:
#                 # ✅ Add selected_columns here
#                 db.session.add(ScreenerProfileItem(
#                     profile_id=new_profile.profile_id,
#                     stock_id=stock_id,
#                     selected_columns=selected_columns
#                 ))

#         db.session.commit()
#         return jsonify({'message': 'Profile created successfully', 'profile_id': new_profile.profile_id})
#     except Exception as e:
#         db.session.rollback()
#         return jsonify({'error': str(e)}), 500



# @screener_bp.route('/api/update_profile/<int:profile_id>', methods=['PUT'])
# def update_profile(profile_id):
#     data = request.get_json()
#     profile_name = data.get('profile_name')
#     symbols = set(data.get('stocks', []))
#     is_default = data.get('is_default', False)
#     selected_columns = data.get('selected_columns', [])
#     screener_id = 1  # TODO: make dynamic later

#     if not profile_name:
#         return jsonify({'error': 'Profile name is required'}), 400

#     try:
#         profile = db.session.query(ScreenerProfile).filter_by(profile_id=profile_id).first()
#         if not profile:
#             return jsonify({'error': 'Profile not found'}), 404

#         profile.profile_name = profile_name
#         profile.is_default = is_default

#         if is_default:
#             db.session.query(ScreenerProfile).filter(
#                 ScreenerProfile.screener_id == screener_id,
#                 ScreenerProfile.profile_id != profile_id
#             ).update({'is_default': False})

#         existing_symbols = {s.symbol for s in db.session.query(Stock.symbol)
#                             .join(ScreenerProfileItem, Stock.stock_id == ScreenerProfileItem.stock_id)
#                             .filter(ScreenerProfileItem.profile_id == profile_id)}

#         to_add = symbols - existing_symbols
#         to_remove = existing_symbols - symbols

    
#         # Remove deselected stocks
#         if to_remove:
#             db.session.query(ScreenerProfileItem).filter(
#                 ScreenerProfileItem.profile_id == profile_id,
#                 ScreenerProfileItem.stock_id.in_(
#                     db.session.query(Stock.stock_id).filter(Stock.symbol.in_(to_remove))
#                 )
#             ).delete(synchronize_session=False)

#         # Add new stocks
#         if to_add:
#             symbol_to_id = dict(db.session.query(Stock.symbol, Stock.stock_id)
#                                 .filter(Stock.symbol.in_(to_add)).all())
#             for symbol in to_add:
#                 stock_id = symbol_to_id.get(symbol)
#                 if stock_id:
#                     db.session.add(ScreenerProfileItem(
#                         profile_id=profile_id,
#                         stock_id=stock_id,
#                         selected_columns=selected_columns
#                     ))

#         if selected_columns:
#             stock_ids_to_update = db.session.query(Stock.stock_id).filter(
#                 Stock.symbol.in_(symbols - to_add)
#             ).all()

#             stock_ids_to_update = [sid[0] for sid in stock_ids_to_update]

#             items = db.session.query(ScreenerProfileItem).filter(
#                 ScreenerProfileItem.profile_id == profile_id,
#                 ScreenerProfileItem.stock_id.in_(stock_ids_to_update)
#             ).all()

#             for item in items:
#                 current_columns = item.selected_columns or []
#                 merged_columns = list(set(current_columns + selected_columns))
#                 item.selected_columns = merged_columns
#             print(merged_columns)

#         db.session.commit()
#         return jsonify({'message': 'Profile updated successfully'})

#     except Exception as e:
#         db.session.rollback()
#         return jsonify({'error': str(e)}), 500


# @screener_bp.route('/api/delete_profile/<int:profile_id>', methods=['DELETE'])
# def delete_profile(profile_id):
#     try:
#         db.session.query(ScreenerProfileItem).filter_by(profile_id=profile_id).delete()
#         db.session.query(ScreenerProfile).filter_by(profile_id=profile_id).delete()
#         db.session.commit()
#         return jsonify({'message': 'Profile deleted successfully'})
#     except Exception as e:
#         db.session.rollback()
#         return jsonify({'error': str(e)}), 500
    
# @screener_bp.route('/')
# def screener_home():
#     return render_template('screener.html')


from flask import render_template
from . import screener_bp, db
import json
from flask import Blueprint, render_template, jsonify, request
from flask_sock import Sock
from flask_cors import CORS
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import relationship
from datetime import datetime

# from modules.database import db
# from modules.screener.models import ScreenerProfile, ScreenerProfileItem, Stock
class Screener(db.Model):
    __tablename__ = 'screener'

    screener_id = db.Column(db.Integer, primary_key=True)
    client_id = db.Column(db.Integer, nullable=False)

    def __repr__(self):
        return f"<Screener {self.screener_id}>"


class ScreenerProfile(db.Model):
    __tablename__ = 'screener_profile'

    profile_id = db.Column(db.Integer, primary_key=True)
    screener_id = db.Column(db.Integer, db.ForeignKey('screener.screener_id'), nullable=False)
    profile_name = db.Column(db.String, nullable=False)
    filters = db.Column(JSONB, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    is_default = db.Column(db.Boolean, default=False)
    def __repr__(self):
        return f"<ScreenerProfile {self.profile_name}>"

from sqlalchemy.dialects.postgresql import JSONB

class ScreenerProfileItem(db.Model):
    __tablename__ = 'screener_profile_items'

    item_id = db.Column(db.Integer, primary_key=True)
    profile_id = db.Column(db.Integer, db.ForeignKey('screener_profile.profile_id'), nullable=False)
    stock_id = db.Column(db.Integer, db.ForeignKey('stock.stock_id'), nullable=False)
    added_at = db.Column(db.DateTime, default=datetime.utcnow)
    selected_columns = db.Column(JSONB)


    __table_args__ = (
        db.UniqueConstraint('profile_id', 'stock_id', name='unique_profile_stock'),
    )

    def __repr__(self):
        return f"<ScreenerProfileItem Profile: {self.profile_id}, Stock: {self.stock_id}>"


class Stock(db.Model):
    __tablename__ = 'stock'

    stock_id = db.Column(db.Integer, primary_key=True)
    symbol = db.Column(db.String(20), nullable=False)
    company = db.Column(db.String(255), nullable=False)
    sector = db.Column(db.String(255), nullable=True)

    def __repr__(self):
        return f"<Stock {self.symbol}>"
    
    
sock = Sock()
clients = []

CORS(screener_bp)


# ========= HTML VIEW ===========
@screener_bp.route('/')
def index():
    return render_template('/screener.html')


# ========= WEBSOCKET ===========
@sock.route('/screener/ws')
def feed_socket(ws):
    clients.append(ws)
    print("🟢 Screener client connected.")
    try:
        while True:
            data = ws.receive()
            if data is None:
                break
    except Exception as e:
        print(f"WebSocket error: {e}")
    finally:
        clients.remove(ws)
        print("🔴 Screener client disconnected.")


# ========= API ROUTES ==========

@screener_bp.route('/api/stocks/symbols')
def get_symbols():
    try:
        symbols = db.session.query(Stock.symbol).distinct().order_by(Stock.symbol).all()
        return jsonify([row[0] for row in symbols])
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@screener_bp.route('/api/stocks/sectors')
def get_sectors():
    try:
        sectors = db.session.query(Stock.sector).distinct().all()
        return jsonify([row[0] for row in sectors])
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@screener_bp.route('/api/get_profiles')
def get_profiles():
    try:
        profiles = db.session.query(ScreenerProfile).filter_by(screener_id=1).all()
        return jsonify([
    {
        'id': p.profile_id,
        'name': p.profile_name,
        'is_default': p.is_default  # Include this
    } for p in profiles
])

    except Exception as e:
        return jsonify({'error': str(e)}), 500


@screener_bp.route('/api/get_profile_stocks/<int:profile_id>')
def get_profile_stocks(profile_id):
    try:
        stocks = db.session.query(Stock.symbol).join(ScreenerProfileItem, Stock.stock_id == ScreenerProfileItem.stock_id) \
            .filter(ScreenerProfileItem.profile_id == profile_id).all()
        return jsonify([row[0] for row in stocks])
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@screener_bp.route('/api/create_profile', methods=['POST'])
def create_profile():
    data = request.get_json()
    profile_name = data.get('profile_name')
    symbols = data.get('stocks', [])
    is_default = data.get('is_default', False)
    screener_id = 1  # TODO: make dynamic later
    selected_columns = data.get("selected_columns", [])

    if not profile_name or not symbols:
        return jsonify({'error': 'Profile name and stocks are required'}), 400

    try:
        if is_default:
            db.session.query(ScreenerProfile).filter_by(
                screener_id=screener_id, is_default=True
            ).update({'is_default': False})

        # ✅ Remove selected_columns here
        new_profile = ScreenerProfile(
            profile_name=profile_name,
            screener_id=screener_id,
            is_default=is_default
        )
        db.session.add(new_profile)
        db.session.flush()  # to get new_profile.profile_id

        stock_ids = dict(db.session.query(Stock.symbol, Stock.stock_id)
                         .filter(Stock.symbol.in_(symbols)).all())

        for symbol in symbols:
            stock_id = stock_ids.get(symbol)
            if stock_id:
                # ✅ Add selected_columns here
                db.session.add(ScreenerProfileItem(
                    profile_id=new_profile.profile_id,
                    stock_id=stock_id,
                    selected_columns=selected_columns
                ))

        db.session.commit()
        return jsonify({'message': 'Profile created successfully', 'profile_id': new_profile.profile_id})
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500




@screener_bp.route('/api/update_profile/<int:profile_id>', methods=['PUT'])
def update_profile(profile_id):
    data = request.get_json()
    profile_name = data.get('profile_name')
    symbols = set(data.get('stocks', []))
    is_default = data.get('is_default', False)
    selected_columns = data.get('selected_columns', [])
    screener_id = 1  # TODO: make dynamic later

    if not profile_name:
        return jsonify({'error': 'Profile name is required'}), 400

    try:
        profile = db.session.query(ScreenerProfile).filter_by(profile_id=profile_id).first()
        if not profile:
            return jsonify({'error': 'Profile not found'}), 404

        profile.profile_name = profile_name
        profile.is_default = is_default
        profile.selected_columns = selected_columns

        if is_default:
            db.session.query(ScreenerProfile).filter(
                ScreenerProfile.screener_id == screener_id,
                ScreenerProfile.profile_id != profile_id
            ).update({'is_default': False})

        existing_symbols = {s.symbol for s in db.session.query(Stock.symbol)
                            .join(ScreenerProfileItem, Stock.stock_id == ScreenerProfileItem.stock_id)
                            .filter(ScreenerProfileItem.profile_id == profile_id)}

        to_add = symbols - existing_symbols
        to_remove = existing_symbols - symbols

        if to_remove:
            db.session.query(ScreenerProfileItem).filter(
                ScreenerProfileItem.profile_id == profile_id,
                ScreenerProfileItem.stock_id.in_(
                    db.session.query(Stock.stock_id).filter(Stock.symbol.in_(to_remove))
                )
            ).delete(synchronize_session=False)

        if to_add:
            symbol_to_id = dict(db.session.query(Stock.symbol, Stock.stock_id)
                                .filter(Stock.symbol.in_(to_add)).all())
            for symbol in to_add:
                stock_id = symbol_to_id.get(symbol)
                if stock_id:
                    db.session.add(ScreenerProfileItem(profile_id=profile_id, stock_id=stock_id, selected_columns=selected_columns ))

        db.session.commit()
        return jsonify({'message': 'Profile updated successfully'})
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@screener_bp.route('/api/delete_profile/<int:profile_id>', methods=['DELETE'])
def delete_profile(profile_id):
    try:
        db.session.query(ScreenerProfileItem).filter_by(profile_id=profile_id).delete()
        db.session.query(ScreenerProfile).filter_by(profile_id=profile_id).delete()
        db.session.commit()
        return jsonify({'message': 'Profile deleted successfully'})
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500


@screener_bp.route('/')
def order_home():
    return render_template('screener.html')