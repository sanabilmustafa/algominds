# Code of wsorder.py from ORDER folder

import ssl
import websocket
import threading
import json
import hashlib
import string
import random
import CREDENTIALS
from .utils import log_order
import time
from . import order_bp
ws = None
stop_event = threading.Event()
from flask import render_template
sent_orders = {}

def checkORderConditions(qty, price):
    if CREDENTIALS.balance <= 0 and (qty * price) > CREDENTIALS.balance and (qty * price) > CREDENTIALS.cashWithdrawalLimit:
        return False
    else: 
        return True

def generateOrderHash():
    rand_str = ''.join(random.choices(string.ascii_letters + string.digits, k=16))
    return hashlib.md5(rand_str.encode()).hexdigest()

# Prepare order payload
def createOrderPayload(user_id, pin, qty, price, symbol, side, client_code, display_qty, market_code):
    return [
        7,
        "newOrder",
        {
            "userId": user_id,
            "pin": pin,
            "ordHash": generateOrderHash(),
            "38": qty,
            "40": 2,
            "44": price,
            "54": side,
            "55": symbol,
            "59": "0",
            "99": 0.0,
            "448": client_code,
            "1138": str(display_qty),
            "1180": market_code
        }
    ]

# WebSocket callbacks
def on_message(ws, message):
    print("Received:", message)
    try:
        data = json.loads(message)
        if data.get("t") == "or":
            order_response = data["d"]
            # Optional: print or log
            print(f"✅ Order Response: {order_response}")

            # Extract last sent order details for logging
            if "ordHash" in order_response:
                # You'll need to keep a mapping of order hashes to symbol/side/price
                if order_response["ordHash"] in sent_orders:
                    order_meta = sent_orders[order_response["ordHash"]]
                    log_order(
                        symbol=order_meta["symbol"],
                        side=order_meta["side"],
                        price=order_meta["price"],
                        response=order_response
                    )
    except Exception as e:
        print(f"⚠️ Error parsing order message: {e}")

def on_open(ws):
    print("✅ WebSocket connected.")

def on_error(ws, error):
    print("❌ WebSocket error:", error)

def on_close(ws, code, reason):
    print(f"🔒 WebSocket closed: {code}, {reason}")
# Open WebSocket once
def start_socket():
    global ws
    ws_url = f"{CREDENTIALS.wsAPI}?socket_token={CREDENTIALS.socket_token}"
    ws = websocket.WebSocketApp(
        ws_url,
        subprotocols=["wamp"],
        on_open=on_open,
        on_message=on_message,
        on_error=on_error,
        on_close=on_close,
    )
    # thread = threading.Thread(target=ws.run_forever)
    thread = threading.Thread(
    target=ws.run_forever,
    kwargs={"sslopt": {"cert_reqs": ssl.CERT_NONE}}
)
    thread.daemon = True
    thread.start()

# Send an order any time
def send_order(user_id, pin, qty, price, symbol, side, client_code, display_qty, market_code):
    global ws
    if checkORderConditions(qty, price):
        print("⚠️ Insufficient balance or withdrawal limit exceeded.")
        return
    elif ws:
        order = createOrderPayload(user_id, pin, qty, price, symbol, side, client_code, display_qty, market_code)
        ord_hash = order[2]["ordHash"]
        
        sent_orders[ord_hash] = {
             "symbol": symbol,
            "side": "buy" if side == 1 else "sell",
            "price": price
        }
        print(order)
        # ws.send(json.dumps(order))
    else:
        print("⚠️ WebSocket is not connected.")



@order_bp.route('/')
def order_home():
    return render_template('order.html')