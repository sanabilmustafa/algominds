                                                                                     algominds-app-compilation/
│
├── config.py               # Configuration settings (DB, secret keys, etc.)
├── requirements.txt
│
├── static/                 # Global static assets (CSS, JS, etc.)
│   ├── 
│   ├──
│   └── 
│           
│
├── templates/              # Global HTML templates (e.g. layout.html)
│
├── modules/                # All your modular apps here
│   ├── strategy/
│   │   ├── __init__.py
│   │   ├── strategy.py          # Flask Blueprint for strategy config UI
│   │   ├── models.py          
│   │   └── templates/
│   │       └── strategy.html
│   │
│   ├── strategy_engine/
│   │   ├── __init__.py     # Blueprint definition
│   │   ├── indicators.py      
│   │   └── position_manager.py      
│   │   └── strategy_runner.py        # This file runs the strategy engine, processing live market data to evaluate strategies, send orders, and manage positions via WebSocket feeds.
│   │   └── tkt_conventional.py       
│   │   └── utils.py       
│   │
│   ├── datafeed/           # stateless module | Handles raw feed from PSX, parses and emits
│   │   ├── __init__.py     # Blueprint definition
│   │   ├── feed_manager.py      # establishes a ZeroMQ connection to receive live data feeds, parses the data, and broadcasts it to connected clients.
│   │   └── state.py      # This file imports and runs the run_datafeed function from feed_manager.py to start the data feed and WebSocket server. 
│   │   └── indicator_server.py     # Broadcasts indicator values every 5 seconds on ws://localhost:8766
│   │   └── utils.py      # This file defines a MarketData database model, parses raw feed data into structured format, and inserts it into the database. 
│   │
│   ├── indicators/         # # All indicator-related logic
│   │   ├── __init__.py     # Blueprint definition
│   │   ├── manager.py      # Subscription tracking, routing requests
│   │   └── calculator.py      # Actual indicator computation logic 
│   │   └── state.py       # Keeps in-memory cache (dict-based for now) 
│   │
│   ├── clients/             # Handles WebSocket connections
│   │   ├── __init__.py     # Blueprint definition
│   │   ├── feed_manager.py      
│   │   └── state.py      
│   │   └── utils.py    
│   │
│   ├── charting/
│   │   ├── __init__.py     # Blueprint definition
│   │   ├── charting.py       # Chart routes
│   │   └── templates/      # charting HTML 
│   │       └── charting.html
│   │
│   ├── userDetails/
│   │   ├── __init__.py     # Blueprint definition
│   │   ├── submit_form.py       # form submission
│   │   └── templates/      # form HTML 
│   │       └── createAccount.html
│   │
│   ├── clientAuth/
│   │   ├── __init__.py     # Blueprint definition
│   │   ├── clientAuth.py       # form submission
│   │   └── templates/      # form HTML 
│   │       └── clientAuth.html
│   │
│   ├── dashboard/
│   │   ├── __init__.py     # Blueprint definition
│   │   ├── dashboard.py       # form submission
│   │   └── templates/      # form HTML 
│   │       └── dashboard.html
│   │
│   ├── screener/
│   │   ├── __init__.py     # Blueprint definition
│   │   ├── screener.py       #  
│   │   └── templates/      # form HTML 
│   │       └── screener.html
│   │
│   └── order/
│       ├── __init__.py     # Blueprint definition
│       ├── order.py       # order sending and ws connections
│       └── templates/      # order page HTML 
│
├── app.py                  # Master Flask App    
└── run.py                   # backend process run(datafeed and strategy_engine)



                        +-------------------------+
                        |   Market Data Feed      |
                        +-----------+-------------+
                                    |
                          (real-time data tick)
                                    ↓
                        +-----------v------------+
                        |     Cache Manager      |  <- Redis + custom logic
                        | - Maintain latest bars |
                        | - Update rolling data  |
                        | - Compute indicator(s) |
                        +-----------+------------+
                                    |
                        +-----------v------------+
                        |     Screener Engine     |  <- Flask logic
                        | - Reads from cache      |
                        | - Applies filters       |
                        +-----------+-------------+
                                    |
                            (return results)


screener model :


             ┌──────────────┐
             │  Web Client  │
             └────┬─────────┘
                  │ (1. Request indicators for visible grid)
                  ▼
        ┌────────────────────────┐
        │ Indicator Sub Router   │
        │ (Manages subscriptions │
        │  + visibility window)  │
        └────┬───────────────────┘
             │
             ▼
    ┌────────────────────────────┐
    │ Indicator Calculation Pool │
    │  (Async workers calculate  │
    │   on symbol+tf+indicator)  │
    └────┬────────────┬──────────┘
         ▼            ▼
    Tick Feed    Bar Memory
    (Live Feed)   (Dict or Redis)



┌───────────────────────────────────────┐  
│{                                      │ 
│  "action": "subscribe",               │
│  "symbols": ["HBL", "OGDC"],          │
│  "indicators": ["sma_20", "rsi_14"]   │
│}                                      │
│  client message                       │
└───────────────────────────────────────┘

{
  "subscribed": true,
  "session_id": "abc123",
  "symbols": [...],
  "indicators": [...]
}



 ssh -L 0.0.0.0:15012:192.168.99.44:15012 root@202.142.180.18 -p 20176
<!-- 

-- Step 1: Create Enum types
CREATE TYPE strategy_status AS ENUM ('Active', 'Inactive', 'Testing');
CREATE TYPE deploy_status AS ENUM ('Deployed', 'Undeployed');

-- Step 2: Create the strategies table
CREATE TABLE strategies (
    strategy_id SERIAL PRIMARY KEY,
    client_id INTEGER NOT NULL,
    strategy_name VARCHAR NOT NULL,
    description TEXT,
    status strategy_status NOT NULL DEFAULT 'Inactive',
    deploy_status deploy_status NOT NULL DEFAULT 'Undeployed',
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);


\copy strategies(client_id, strategy_name, description, status, deploy_status, stocks, allocation_of_assets, strategy_author) FROM '/Users/sanabilmustafa/Documents/Analytics/algominds-app-compilation/modules/strategy/strategies.csv' DELIMITER '-' CSV HEADER;
\copy strategy_stock_allocations(id, strategy_id, stock_symbol,allocation_percent) FROM '/Users/sanabilmustafa/Documents/Analytics/algominds-app-compilation/modules/strategy/stocks_strategies.csv' DELIMITER ',' CSV HEADER;
 -->



   <!-- <div class="strategy">
                    <div class="strategy-card-header">
                        <h3>TKT</h3>
                        <div class="strategy-status">
                            <p class="status-inactive">Inactive</p>
                            <label class="switch">
                                <input type="checkbox">
                                <span class="slider round"></span>
                            </label>
                        </div>
                    </div>
                    <div class="strategy-card-author">
                        <p>by <span class="author-name">ALGOMINDS</span></p>
                    </div>
                    <div class="strategy-time">
                        <p><i class="fa-solid fa-clock"></i>starts: <span class="time">9:30 a.m.</span></p>
                        <p><i class="fa-solid fa-clock"></i>ends: <span class="time">3:30 p.m.</span></p>
                    </div>
                    <div class="strategy-characteristics">
                        <div class="char">
                            <p class="key">Type: </p>
                            <p class="value">Short Term</p>
                        </div>
                        <div class="char">
                            <p class="key">Asset Class: </p>
                            <p class="value">Stock</p>
                        </div>
                        <div class="">
                            <form method="">
                                <div class="char">
                                    <label for="stocks">Select Stocks:</label>
                                    <select name="stocks" multiple class="stock-select">
                                        {% for symbol in stock_symbols %}
                                        <option value="{{ symbol }}">{{ symbol }}</option>
                                        {% endfor %}
                                    </select>
                                </div>
                                <div class="char">
                                    <label for="allocation_of_balance">Allocation (%) of Total Balance:</label>
                                    <input type="text" name="allocation_of_balance" id="allocation_of_balance">
                                </div>
                                <button class="deploy-btn">Deploy</button>
                            </form>

                        </div>
                    </div>
                </div> -->



\copy 
        market_data(
        record_identifier,
        symbol_code,
        market_code,
        symbol_state,
        symbol_flag,
        bid_volume,
        bid_price,
        ask_price,
        ask_volume,
        last_trade_price,
        last_trade_volume,
        last_trade_time,
        last_day_close_price,
        symbol_direction,
        average_price,
        high_price,
        low_price,
        net_change,
        total_traded_volume,
        total_trades,
        open_price,
        timestamp
) 
FROM '/Users/rubasmustafa/Desktop/16-07-25-parsed.csv' 
DELIMITER ',' 
CSV HEADER;