userid = "TEST05"     
password = "Test05@"      
pin = '1111'
secret_key = "LHaJpfvuJjDoSjW7q8ejMJr3ZUjTtKMv"
api = "http://15.235.153.112/api"
tradingAPI = "https://tlapi.munirkhanani.com/api"
wsAPI = "wss://tlapi.munirkhanani.com:24002"
socket_token = 'ZXlKMGVYQWlPaUpLVjFRaUxDSmhiR2NpT2lKSVV6STFOaUo5LmV5SnBZWFFpT2pFM05USTFOakF6TWpNc0ltVjRjQ0k2TVRjMU1qVTJOelV5TXl3aWRYTmxjbTVoYldVaU9pSlVSVk5VTURVaUxDSnBjME52Ym01bFkzUWlPaUpaSWl3aWRXNXhJam9pVFdwVk5FOVVWVDBpZlEuYTBEaFRFNE1yZ1hSNFVSX3Bib01xbTdpN2lkbTBQQmpseGU2REZpcllYZw=='
Authorization = 'Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpYXQiOjE3NTI1NjAzMjMsImV4cCI6MTc1MjU2MDkyMywiY2xpZW50X2lkIjoiVEVTVDA1Iiwic2VxX25vIjoiMTc3IiwibG9naW5fdW5pcXVlX2lkIjoiMjU4OTUiLCJsb2dpbl91bmlxdWVfaWRfZW5jIjoiMEpaQiIsImlzQ29ubmVjdCI6MH0.BL4vbC__OEYgWMizL4HhVEUtGLHW8jgY7L6ygSEkWwo'
X_Refresh_Token = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpYXQiOjE3NTI1NjAzMjMsImV4cCI6MTc1MjU2MTIyMywiY2xpZW50X2lkIjoiVEVTVDA1Iiwic2VxX25vIjoiMTc3IiwibG9naW5fdW5pcXVlX2lkIjoiMjU4OTUiLCJsb2dpbl91bmlxdWVfaWRfZW5jIjoiMEpaQiIsImlzQ29ubmVjdCI6MH0.F_ReUIPICpf4ZN8408p4icDpLVNw3hkwQ046Z4Yw8KM'
client_code = 222
app_secret_key = '0642fa7bdc069bf88a4d634c89ddfc95'

pendingOrderValue = 0.0
portfolioMarketValue = 1236.81
totalWorth = 9772.15
balance = 8535.34
cashWithdrawalLimit = 3535.34

useridtl = '222C'
passwordtl = 'S@101tl'
pintl = 1811

dbname = 'AlgoMinds'
dbpassword = 'machinedatabase'
dbuser = 'algominds'
