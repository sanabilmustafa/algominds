# strategy_subscriber.py

import asyncio
import websockets
import json
import psycopg2
from psycopg2.extras import RealDictCursor
from strategy_logic import tkt_modified  # Import the strategy logic module

# Constants
DB_CONFIG = {
    'dbname': 'AlgoMinds',
    'user': 'algominds',
    'password': 'machinedatabase',
    'host': 'localhost',
    'port': 5432
    
}

# WS_URI = "https://8a52c52d9da0.ngrok-free.app"
    #  https://6eca39b05238.ngrok-free.a
WS_URI = 'ws://localhost:8765'


# Hardcoded indicators per strategy (this will later be dynamic or plugin-based)
STRATEGY_INDICATORS = {
    "TKT modified": ["sma", "rsi"],
}

def get_active_deployed_strategies():
    conn = psycopg2.connect(**DB_CONFIG)
    cur = conn.cursor(cursor_factory=RealDictCursor)

    # Fetch active and deployed strategies
    cur.execute("""
        SELECT strategy_id, strategy_name
        FROM strategies
        WHERE deploy_status = 'Deployed' AND status = 'Active'
    """)
    strategies = cur.fetchall()

    # Fetch symbols for each strategy
    strategy_subscriptions = []
    for strategy in strategies:
        cur.execute("""
            SELECT stock_symbol
            FROM strategy_stock_allocations
            WHERE strategy_id = %s
        """, (strategy['strategy_id'],))
        symbols = [row['stock_symbol'] for row in cur.fetchall()]

        indicators = STRATEGY_INDICATORS.get(strategy['strategy_name'], [])
        if symbols and indicators:
            strategy_subscriptions.append({
                'strategy_id': strategy['strategy_id'],
                'strategy_name': strategy['strategy_name'],
                'symbols': symbols,
                'indicators': indicators
            })

    cur.close()
    conn.close()
    print(strategy_subscriptions)
    return strategy_subscriptions

def handle_incoming_data(data):
    print("handle incoming data called")
    symbol = data["symbol"]
    tick = data["tick"]
    indicators = data["indicators"]

    # Evaluate strategy
    tkt_modified.run(symbol, tick, indicators, market_is_open=True)

async def send_subscription(strategy_subs):
    async with websockets.connect(WS_URI) as websocket:
        print("✅ Connected to client-server")

        for strategy in strategy_subs:
            subscription = {
                "request": "subscribe",
                "symbols": strategy['symbols'],
                "indicators": strategy['indicators'],
                # "strategy_id": strategy['strategy_id']
            }
            print(f"📤 Sending subscription for {strategy['strategy_name']}:")
            print(json.dumps(subscription, indent=2))
            print("sending subscription to client-server: ", json.dumps(subscription))
            await websocket.send(json.dumps(subscription))

        # Keep listening to incoming data (optional)
        while True:
            message = await websocket.recv()
            data = json.loads(message)
            print("📩 Received:", data)
            handle_incoming_data(data)

def main():
    strategy_subs = get_active_deployed_strategies()
    if not strategy_subs:
        print("❌ No active, deployed strategies found.")
        return

    asyncio.run(send_subscription(strategy_subs))

if __name__ == "__main__":
    main()
